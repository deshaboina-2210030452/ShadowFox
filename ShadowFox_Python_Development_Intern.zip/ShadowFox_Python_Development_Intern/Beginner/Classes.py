class Avenger:
    def __init__(self,Name,Age,Gender,Super_Power,Weapon):
        self.Name=Name
        self.Age=Age
        self.Gender=Gender
        self.Super_power=Super_Power
        self.Weapon=Weapon
    def get_info(self):
        return f"Name :{self.Name} ,Age :{self.Age},Gender :{self.Gender},Super_power:{self.Super_power},Weapon:{self.Weapon}"
    def is_leader(self):
        if self.Name=="Captain America":
            return True
        else:
            return False
Super_heroes=[
{"name": "Captain America", "age": 100, "gender": "Male", "super_power": "Super Strength", "weapon": "Shield"},
    {"name": "Iron Man", "age": 45, "gender": "Male", "super_power": "Technology", "weapon": "Armor"},
    {"name": "Black Widow", "age": 35, "gender": "Female", "super_power": "Superhuman", "weapon": "Batons"},
    {"name": "Hulk", "age": 40, "gender": "Male", "super_power": "Unlimited Strength", "weapon": "No Weapon"},
    {"name": "Thor", "age": 1000, "gender": "Male", "super_power": "Super Energy", "weapon": "Mjölnir"},
    {"name": "Hawkeye", "age": 45, "gender": "Male", "super_power": "Fighting Skills", "weapon": "Bow and Arrows"}
]
avenger=[Avenger(hero['name'],hero['age'],hero['gender'],hero['super_power'],hero['weapon']) for hero in Super_heroes]
for heroes in avenger:
    print(heroes.get_info())
    if heroes.is_leader():
        print("Leader")
    else:
        print("Not a Leader")

