friends=["ravi","ram","baji","charith","saketh"]
l=[]
for i in friends:
    l.append((i,len(i)))
print(friends)
print(l)

#2
your_expenses = { "Hotel": 1200, "Food": 800, "Transportation": 500,
                            "Attractions": 300, "Miscellaneous": 200}
partner_expenses = { "Hotel": 1000, "Food": 900, "Transportation": 600,
                            "Attractions": 400, "Miscellaneous": 150 }
total_y=0
total_p=0
for key,values in your_expenses.items():
    total_y+=your_expenses[key]
    total_p+=partner_expenses[key]
    print(key,"difference between both expenses=",abs(your_expenses[key]-partner_expenses[key]))
if total_y>total_p:
    print("your expenses are more")
else:
    print("partner expenses are more")




