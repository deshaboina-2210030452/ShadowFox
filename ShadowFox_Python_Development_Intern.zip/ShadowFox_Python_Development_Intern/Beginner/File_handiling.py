# 1
import csv
with open('Student_Marks.csv','r') as file:
    reader=csv.reader(file)
    for row in reader:
        print(row)
# 2
import csv
dis={'number_courses':[],'time_study':[],'Marks':[]}
with open('Student_Marks.csv','r') as file:
    reader=csv.DictReader(file)
    for row in reader:
        dis['number_courses'].append(int(row['number_courses']))
        dis['time_study'].append(float(row['time_study']))
        dis['Marks'].append(float(row['Marks']))
print(dis)