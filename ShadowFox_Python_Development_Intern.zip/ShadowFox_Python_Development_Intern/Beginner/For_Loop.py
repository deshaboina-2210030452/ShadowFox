#1
import random
dice=[1,2,3,4,5,6]
count_6=0
count_1=0
count_66=0
n=20
d=0
for i in range(n):
    c=random.choice(dice)
    print(c,end=" ")
    if c==6:
        count_6+=1
    if c==1:
        count_1+=1
    if d==6 and c==6:
        count_66+=1
        d=0
    if c==6:
        d=6
    else:
        d=0
print()
print("count of 6=",count_6)
print("count of 1=",count_1)
print("count of two 6 repeated",count_66)

#2
present=0
for i in range(10):

    if present==100:
        print("Congratulations! You completed the workout")
        break
    Q1=input("Are you tired? = ")
    if Q1=="y" or Q1=="yes":
        Q2=input("do you want to skip the remaining sets = ")
        if Q2=="y" or Q2=="yes":
            print("You completed a total of ",present," jumping jacks")
            break
        elif Q2=="n" or Q2=="no":
            print(100-present," jumping jacks are remaining")
            present = present + 10
    else:
        print("You completed a total of ",present," jumping jacks")
        present = present + 10







