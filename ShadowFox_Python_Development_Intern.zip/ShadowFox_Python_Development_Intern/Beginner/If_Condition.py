#1
H=float(input("Enter Height in meters="))
W=int(input("Enter Weight in Kilometers"))
BMI=W/(H*H)
if BMI<18.5:
    print("Underweight")
elif BMI>=18.5 and BMI<25:
    print("Normal")
elif BMI>=25 and BMI<29:
    print("Overweight")
else:
    print("Obesity")


#2
Australia = ["Sydney","Melbourne","Brisbane","Perth"]
UAE = ["Dubai","Abu Dhabi","Sharjah","Ajman"]
India = ["Mumbai","Bangalore","Chennai","Delhi"]
user=input("Enter a city name=")
if user in Australia:
    print(user," is in ","Australia")
elif user in UAE:
    print(user," is in UAE")
else:
    print(user,"is in India")
#3
city1,city2=map(str,input("Enter city names").split())
if city1 and city2 in Australia:
    print("Both cities are in Australia")
elif city1 and city2 in India:
    print("Both cities are in India")
elif city1 and city2 in UAE:
    print("Both cities are in UAE")
else:
    print("Both are not in same country")


