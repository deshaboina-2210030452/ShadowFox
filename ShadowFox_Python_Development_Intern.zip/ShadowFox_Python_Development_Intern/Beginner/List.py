justice_league = ["Superman","Batman","Wonder Woman","Flash","Aquaman","Green Lantern"]
#1
print("number of members in justice_league",len(justice_league))

#2
justice_league.append("Batgirl")
justice_league.append("Nightwing")
print(justice_league)

#3
p=justice_league.pop(justice_league.index("Wonder Woman"))
justice_league.insert(0,p)
print(justice_league)

#4
p=justice_league.pop(justice_league.index("Superman"))
justice_league.insert(justice_league.index("Flash")+1,p)
print(justice_league)

#5
justice_league=["Cyborg","Shazam","Hawkgirl","Martian Manhunter","Green Arrow"]
print(justice_league)

#6
justice_league.sort()
print(justice_league)
print("New leader=",justice_league[0])
