#1
def formated_string(string,num):
    result=format(num,string)
    return result
num=145
string='o'
result=formated_string(string,num)
print("formated String",result)


#2
import math
r=84
area=r*r*3.14
print("Area of pond=",area)
sq_m=1.4
total_water_in_pond=int(sq_m*area)
print("Total water in the pond=",total_water_in_pond)


#3
Distance=490
Time=7
Time_s=Time*60
speed=Distance//Time_s
print("speed in meter per second=",speed)

