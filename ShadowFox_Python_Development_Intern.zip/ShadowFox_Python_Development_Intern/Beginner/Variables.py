#1
pi=22/7
print(type(pi))

#2
# for=4
# SyntaxError: invalid
# syntax

#3
P = 1000
R = 5
T= 3
simple_interest = (P*R*T) / 100
print("The Simple Interest for 3 years is:", simple_interest)


