import random
words = ["hangman", "python", "computer", "programming", "code", "algorithm", "variable", "function"]
def chooseWord():
    word=random.choice(words)
    return word
def display_hangman(attempts_left):
    stages = [
        """
           --------
           |      |
           |      
           |      
           |      
           |      
        ------
        """,
        """
           --------
           |      |
           |      O
           |     
           |     
           |     
        ------
        """,
        """
           --------
           |      |
           |      O
           |      |
           |     
           |     
        ------
        """,
        """
           --------
           |      |
           |      O
           |     /|
           |     
           |     
        ------
        """,
        """
           --------
           |      |
           |      O
           |     /|\\
           |     
           |     
        ------
        """,
        """
           --------
           |      |
           |      O
           |     /|\\
           |     / 
           |     
        ------
        """,
        """
           --------
           |      |
           |      O
           |     /|\\
           |     / \\
           |     
        ------
        """
    ]
    return stages[attempts_left]
def displayWord(word, guessed_letters):
    display = ""
    for letter in word:
        if letter in guessed_letters:
            display += letter + " "
        else:
            display += "_ "
    return display.strip()

def get_guess(guessed_letters):
    while True:
        guess = input("Guess a letter: ").lower()
        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single letter.")
        elif guess in guessed_letters:
            print("You've already guessed that letter.")
        else:
            return guess
def hangman():
    word=chooseWord()
    guessed_letters=[]
    remaining_attempts=6
    print("Welcome to Hangman")
    print(f"Length of chossen word ={len(word)}")
    while True:
        print("attempts left= ",remaining_attempts)
        print(display_hangman(remaining_attempts))
        print("Progress = ",displayWord(word,guessed_letters))
        if remaining_attempts == 0:
            print("You ran out of attempts. The word was:", word)
            break

        if "_" not in displayWord(word, guessed_letters):
            print("Congratulations! You guessed the word:", word)
            break
        guess = get_guess(guessed_letters)
        guessed_letters.append(guess)

        if guess not in word:
            remaining_attempts -= 1
            print("Incorrect guess!")
hangman()
