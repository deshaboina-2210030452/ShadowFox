from bs4 import BeautifulSoup
import requests
html1=requests.get('https://www.cricbuzz.com/cricket-team/india/2/players').text
soup1=BeautifulSoup(html1,'lxml')
cricketers=soup1.find_all('div',class_='cb-col-67 cb-col cb-left cb-top-zero')
print("Team India players")
for play in cricketers:
    print(play.text)
with open('Team_India_Players.txt','w') as P:
    P.write("=====>Team India Players:<=====\n")
    for player in cricketers:
        P.write(player.text)
        P.write("\n")




html2=requests.get('https://www.cricbuzz.com/cricket-team/india/2/stats').text
soup2=BeautifulSoup(html2,'lxml')
top=soup2.find_all('a',class_='cb-text-link')
print("Top batsman in all formates")
avg=soup2.find_all('td',class_='cb-srs-stats-td')
l=len(top)
for i in range(l):
    print(top[i].text,avg[i].text)
print("Leading run scorer in all formates=",top[1].text)
with open('Top_Indian_scorer.txt','w') as T:
    T.write("Top Indian Scorer Up to Date\n")
    for i in range(l-1):
        T.write(f"{i+1}=>{top[i+1].text}\n")
    T.write("Leading run scorer in all formates\n")
    T.write(f"***********{top[1].text}*************")




html3=requests.get('https://www.cricbuzz.com/cricket-schedule/upcoming-series/all').text
soup3=BeautifulSoup(html3,'lxml')
upcoming_matches=soup3.find_all('div',class_='cb-col-100 cb-col')
for up in upcoming_matches:
    schedule=up.find_all('div',class_='cb-lv-grn-strip text-bold')
    match=up.find_all('a',class_='cb-col-33 cb-col cb-mtchs-dy text-bold')
    for dat in schedule:
        print("========>",dat.text,"<========")
    for m1 in match:
        print(m1.text)
        


#"sample html file"
# from bs4 import BeautifulSoup
# with open('Home.html','r') as html_file:
#     code=html_file.read()
#     # print(code)
#     soup=BeautifulSoup(code,'lxml')
#     # print(soup.prettify())
#     # course_html_tap=soup.find_all('h3')
#     # print(course_html_tap)
#     # for course in course_html_tap:
#     #     print(course.text)
#     course_tap=soup.find_all('div',class_='course')
#     for course in course_tap:
#         print(course.h3.text)
#         print(course.p.text.strip())